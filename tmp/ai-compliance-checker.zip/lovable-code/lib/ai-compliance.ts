// lib/ai-compliance.ts
// AI-powered compliance document analysis

interface PropertyDetails {
  address: string;
  postcode: string;
  id: string;
}

interface AIAnalysisResult {
  documentType: string;
  issueDate: string;
  expiryDate: string;
  isExpired: boolean;
  daysUntilExpiry: number;
  matchesPropertyAddress: boolean;
  confidence: number;
  issues: Array<{
    type: string;
    message: string;
    severity: 'critical' | 'warning' | 'info';
  }>;
  [key: string]: any; // For type-specific fields
}

// Build AI prompt based on compliance type
const buildAnalysisPrompt = (
  complianceType: string,
  documentText: string,
  property: PropertyDetails
): string => {
  const basePrompt = `You are a property compliance expert analyzing documents for a UK property portfolio.

Document Type: ${complianceType}
Property Address: ${property.address}
Property Postcode: ${property.postcode}

Analyze the following document and extract key information. Return ONLY valid JSON with no markdown formatting or code blocks.

Document Text:
${documentText}

Extract the following information and validate it:`;

  const typeSpecificPrompts: Record<string, string> = {
    'Gas Safety Certificate': `
{
  "documentType": "Gas Safety Certificate",
  "issueDate": "DD/MM/YYYY format",
  "expiryDate": "DD/MM/YYYY format",
  "engineerName": "Name of Gas Safe engineer",
  "gasSafeNumber": "Gas Safe registration number",
  "propertyAddress": "Full address from certificate",
  "landlordName": "Name of landlord/property owner",
  "appliancesChecked": ["list of appliances checked"],
  "defectsFound": "Any defects or issues mentioned",
  "overallStatus": "PASS or FAIL or AT RISK",
  "isExpired": boolean,
  "daysUntilExpiry": number (negative if expired),
  "matchesPropertyAddress": boolean,
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- Gas Safety Certificates are valid for 12 months
- Must have a Gas Safe registration number
- Property address should match: ${property.address}
- Issue date must be before expiry date
- If expired, flag as critical issue
- If defects found, include in issues array`,

    'EPC': `
{
  "documentType": "EPC",
  "certificateNumber": "EPC reference number",
  "dateOfAssessment": "DD/MM/YYYY",
  "validUntil": "DD/MM/YYYY",
  "currentRating": "A-G rating",
  "potentialRating": "A-G rating",
  "currentScore": number,
  "potentialScore": number,
  "propertyAddress": "Full address",
  "propertyType": "House/Flat/Bungalow etc",
  "isExpired": boolean,
  "meetsMinimumStandard": boolean (E or above),
  "daysUntilExpiry": number,
  "matchesPropertyAddress": boolean,
  "recommendations": ["improvement recommendations"],
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- EPCs valid for 10 years
- Minimum rating must be E for new tenancies (since April 2020)
- Property address must match: ${property.address}`,

    'EICR': `
{
  "documentType": "EICR",
  "dateOfInspection": "DD/MM/YYYY",
  "nextInspectionDue": "DD/MM/YYYY",
  "electricianName": "Name of qualified electrician",
  "registrationNumber": "Electrician registration number",
  "propertyAddress": "Full address",
  "overallCondition": "Satisfactory or Unsatisfactory",
  "c1Codes": number (danger present),
  "c2Codes": number (potentially dangerous),
  "c3Codes": number (improvement recommended),
  "fiCodes": number (further investigation),
  "isExpired": boolean,
  "daysUntilExpiry": number,
  "requiresImmediateAction": boolean,
  "matchesPropertyAddress": boolean,
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- EICRs valid for 5 years (HMOs and new tenancies)
- Any C1 or C2 codes are critical issues
- Must have electrician registration number
- Property address must match: ${property.address}`,

    'HMO Licence': `
{
  "documentType": "HMO License",
  "licenseNumber": "License reference number",
  "issueDate": "DD/MM/YYYY",
  "expiryDate": "DD/MM/YYYY",
  "propertyAddress": "Full licensed address",
  "maxOccupants": number,
  "maxHouseholds": number,
  "licenseHolderName": "Name on license",
  "localAuthority": "Council name",
  "conditions": ["any special conditions"],
  "isExpired": boolean,
  "daysUntilExpiry": number,
  "matchesPropertyAddress": boolean,
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- HMO licenses typically 5 years
- Property address must exactly match: ${property.address}
- License holder should match property owner
- Check if approaching renewal (within 3 months)`,

    'Fire Alarm Certificate': `
{
  "documentType": "Fire Alarm Certificate",
  "dateOfService": "DD/MM/YYYY",
  "nextServiceDue": "DD/MM/YYYY",
  "engineerName": "Name of engineer/company",
  "certificateNumber": "Certificate reference",
  "propertyAddress": "Full address",
  "systemType": "Type of fire alarm system",
  "testsPerformed": ["list of tests"],
  "defectsFound": "Any issues found",
  "overallStatus": "PASS or FAIL",
  "isExpired": boolean,
  "daysUntilExpiry": number,
  "matchesPropertyAddress": boolean,
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- Fire alarm servicing typically annual
- Property address must match: ${property.address}
- Any defects should be flagged as critical`,

    'Emergency Lighting Certificate': `
{
  "documentType": "Emergency Lighting Certificate",
  "dateOfTest": "DD/MM/YYYY",
  "nextTestDue": "DD/MM/YYYY",
  "engineerName": "Name of engineer/company",
  "certificateNumber": "Certificate reference",
  "propertyAddress": "Full address",
  "numberOfLuminaires": number,
  "testsPerformed": ["list of tests"],
  "failuresFound": "Any failures",
  "overallStatus": "PASS or FAIL",
  "isExpired": boolean,
  "daysUntilExpiry": number,
  "matchesPropertyAddress": boolean,
  "issues": [{"type": "string", "message": "string", "severity": "critical|warning|info"}],
  "confidence": number 0-100
}

Validation Rules:
- Emergency lighting tests typically 6-monthly
- Property address must match: ${property.address}
- Any failures should be flagged as critical`
  };

  return basePrompt + (typeSpecificPrompts[complianceType] || typeSpecificPrompts['Gas Safety Certificate']);
};

// Analyze document with Claude AI
export const analyzeComplianceDocument = async (
  documentText: string,
  complianceType: string,
  property: PropertyDetails
): Promise<AIAnalysisResult> => {
  const prompt = buildAnalysisPrompt(complianceType, documentText, property);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': import.meta.env.VITE_ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 2000,
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.statusText}`);
    }

    const data = await response.json();
    const analysisText = data.content[0].text;

    // Remove any markdown code blocks if present
    const cleanText = analysisText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();

    const analysis: AIAnalysisResult = JSON.parse(cleanText);

    return analysis;
  } catch (error) {
    console.error('AI analysis failed:', error);
    throw new Error('Failed to analyze document with AI');
  }
};

// Validate AI extraction results
export const validateAIExtraction = (aiAnalysis: AIAnalysisResult) => {
  const additionalIssues: AIAnalysisResult['issues'] = [];
  let isValid = true;

  // Check confidence level
  if (aiAnalysis.confidence < 70) {
    additionalIssues.push({
      type: 'low_confidence',
      message: 'AI is not highly confident about extracted information. Please review carefully.',
      severity: 'warning',
    });
    isValid = false;
  }

  // Check if expired
  if (aiAnalysis.isExpired) {
    additionalIssues.push({
      type: 'expired',
      message: `Document expired ${Math.abs(aiAnalysis.daysUntilExpiry)} days ago`,
      severity: 'critical',
    });
    isValid = false;
  }

  // Check expiring soon (within 30 days)
  if (!aiAnalysis.isExpired && aiAnalysis.daysUntilExpiry < 30 && aiAnalysis.daysUntilExpiry > 0) {
    additionalIssues.push({
      type: 'expiring_soon',
      message: `Expires in ${aiAnalysis.daysUntilExpiry} days`,
      severity: 'warning',
    });
  }

  // Check property address match
  if (!aiAnalysis.matchesPropertyAddress) {
    additionalIssues.push({
      type: 'address_mismatch',
      message: 'Document address does not match property address',
      severity: 'critical',
    });
    isValid = false;
  }

  // Type-specific validations
  if (aiAnalysis.documentType === 'EICR' && aiAnalysis.c1Codes > 0) {
    additionalIssues.push({
      type: 'critical_defects',
      message: `${aiAnalysis.c1Codes} dangerous conditions found (C1 codes)`,
      severity: 'critical',
    });
    isValid = false;
  }

  if (aiAnalysis.documentType === 'EPC' && !aiAnalysis.meetsMinimumStandard) {
    additionalIssues.push({
      type: 'below_minimum',
      message: `EPC rating ${aiAnalysis.currentRating} is below minimum standard (E)`,
      severity: 'critical',
    });
    isValid = false;
  }

  // Combine issues
  const allIssues = [...(aiAnalysis.issues || []), ...additionalIssues];

  return {
    isValid: isValid && allIssues.filter((i) => i.severity === 'critical').length === 0,
    issues: allIssues,
    autoApprove: isValid && allIssues.length === 0,
  };
};
