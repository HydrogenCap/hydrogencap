// lib/pdf-utils.ts
// PDF text extraction using pdf.js

import * as pdfjsLib from 'pdfjs-dist';

// Set up the worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

/**
 * Extract text from a PDF file
 */
export const extractTextFromPDF = async (file: File): Promise<string> => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

    let fullText = '';

    // Extract text from each page
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();

      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');

      fullText += pageText + '\n\n';
    }

    return fullText.trim();
  } catch (error) {
    console.error('PDF extraction failed:', error);
    throw new Error('Failed to extract text from PDF');
  }
};

/**
 * Extract text from an image using OCR (placeholder - requires Tesseract.js)
 * For now, just return a message that OCR is needed
 */
export const extractTextFromImage = async (file: File): Promise<string> => {
  // You would need to install Tesseract.js for this
  // For now, we'll just return a placeholder
  return 'OCR extraction not yet implemented. Please upload PDF documents.';
};

/**
 * Determine file type and extract text accordingly
 */
export const extractTextFromDocument = async (file: File): Promise<string> => {
  if (file.type === 'application/pdf') {
    return extractTextFromPDF(file);
  } else if (file.type.startsWith('image/')) {
    return extractTextFromImage(file);
  } else {
    throw new Error('Unsupported file type. Please upload PDF or image files.');
  }
};
