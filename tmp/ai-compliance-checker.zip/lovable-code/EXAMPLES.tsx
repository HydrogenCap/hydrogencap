// EXAMPLE USAGE: How to integrate the AI Compliance Checker

// 1. SIMPLE INTEGRATION - Property Detail Page
// ==============================================

import { ComplianceChecklist } from '@/components/ComplianceChecklist';
import { supabase } from '@/lib/supabase'; // Or your database client

export const PropertyDetailPage = ({ propertyId }: { propertyId: string }) => {
  // Your existing property data
  const property = {
    id: propertyId,
    address: '47 Pinewood Drive, Cheltenham',
    postcode: 'GL51 9QH',
  };

  // Handle saving compliance data
  const handleComplianceUpdate = async (data: any) => {
    try {
      // Save to database
      const { error } = await supabase.from('compliance_records').insert({
        property_id: data.propertyId,
        compliance_type: data.complianceType,
        issue_date: data.issueDate,
        expiry_date: data.expiryDate,
        status: data.status,
        auto_verified: data.autoVerified,
        ai_analysis: data.aiAnalysis,
      });

      if (error) throw error;

      // Optionally upload the file to storage
      if (data.file) {
        const fileName = `${propertyId}/${data.complianceType}-${Date.now()}.pdf`;
        const { error: uploadError } = await supabase.storage
          .from('compliance-documents')
          .upload(fileName, data.file);

        if (uploadError) throw uploadError;
      }

      console.log('Compliance record saved!');
    } catch (error) {
      console.error('Failed to save:', error);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">{property.address}</h1>

      {/* Your existing property sections */}
      <div className="mb-6">
        {/* Property info, financials, etc */}
      </div>

      {/* AI Compliance Checker */}
      <ComplianceChecklist property={property} onUpdate={handleComplianceUpdate} />
    </div>
  );
};

// 2. WITH EXISTING RECORDS - Loading Previous Uploads
// ====================================================

import { useEffect, useState } from 'react';
import { ComplianceChecklistItem } from '@/components/ComplianceChecklistItem';

export const PropertyComplianceTab = ({ propertyId }: { propertyId: string }) => {
  const [existingRecords, setExistingRecords] = useState<any[]>([]);

  useEffect(() => {
    // Load existing compliance records
    const loadRecords = async () => {
      const { data } = await supabase
        .from('compliance_records')
        .select('*')
        .eq('property_id', propertyId);

      setExistingRecords(data || []);
    };

    loadRecords();
  }, [propertyId]);

  return (
    <div className="space-y-4">
      {COMPLIANCE_TYPES.map((type) => {
        const existingRecord = existingRecords.find((r) => r.compliance_type === type);

        return (
          <ComplianceChecklistItem
            key={type}
            complianceType={type}
            propertyId={propertyId}
            propertyAddress="47 Pinewood Drive"
            propertyPostcode="GL51 9QH"
            existingRecord={existingRecord}
            onUpdate={handleUpdate}
          />
        );
      })}
    </div>
  );
};

// 3. BULK UPLOAD - Process Multiple Properties
// =============================================

export const BulkComplianceUpload = ({ propertyIds }: { propertyIds: string[] }) => {
  const [currentPropertyIndex, setCurrentPropertyIndex] = useState(0);

  const properties = [
    { id: '1', address: '47 Pinewood Drive', postcode: 'GL51 9QH' },
    { id: '2', address: '12 Thames Road', postcode: 'GL52 3AB' },
    // ... more properties
  ];

  const handleNext = () => {
    if (currentPropertyIndex < properties.length - 1) {
      setCurrentPropertyIndex(currentPropertyIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentPropertyIndex > 0) {
      setCurrentPropertyIndex(currentPropertyIndex - 1);
    }
  };

  const currentProperty = properties[currentPropertyIndex];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2>
          Property {currentPropertyIndex + 1} of {properties.length}
        </h2>
        <div className="flex gap-2">
          <button onClick={handlePrevious} disabled={currentPropertyIndex === 0}>
            Previous
          </button>
          <button onClick={handleNext} disabled={currentPropertyIndex === properties.length - 1}>
            Next
          </button>
        </div>
      </div>

      <ComplianceChecklist property={currentProperty} onUpdate={saveToDatabase} />
    </div>
  );
};

// 4. WITH NOTIFICATIONS - Alert on Issues
// ========================================

import { useToast } from '@/hooks/use-toast';

export const ComplianceWithNotifications = ({ property }: { property: any }) => {
  const { toast } = useToast();

  const handleComplianceUpdate = async (data: any) => {
    // Check for critical issues
    const criticalIssues = data.aiAnalysis?.issues?.filter(
      (i: any) => i.severity === 'critical'
    );

    if (criticalIssues?.length > 0) {
      toast({
        title: '⚠️ Critical Issues Found',
        description: `${data.complianceType} has critical issues that need immediate attention.`,
        variant: 'destructive',
      });
    }

    // Check if expiring soon
    if (data.aiAnalysis?.daysUntilExpiry < 30 && data.aiAnalysis?.daysUntilExpiry > 0) {
      toast({
        title: '📅 Expiring Soon',
        description: `${data.complianceType} expires in ${data.aiAnalysis.daysUntilExpiry} days.`,
      });
    }

    // Save to database
    await saveToDatabase(data);

    toast({
      title: '✅ Saved Successfully',
      description: `${data.complianceType} has been verified and saved.`,
    });
  };

  return <ComplianceChecklist property={property} onUpdate={handleComplianceUpdate} />;
};

// 5. DASHBOARD INTEGRATION - Show Compliance Status
// ==================================================

export const ComplianceDashboard = () => {
  const [stats, setStats] = useState({
    total: 0,
    valid: 0,
    expiring: 0,
    expired: 0,
  });

  useEffect(() => {
    const loadStats = async () => {
      const { data } = await supabase.from('compliance_records').select('*');

      const now = new Date();
      const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

      const valid = data?.filter((r) => new Date(r.expiry_date) > thirtyDaysFromNow).length || 0;
      const expiring = data?.filter(
        (r) =>
          new Date(r.expiry_date) > now && new Date(r.expiry_date) <= thirtyDaysFromNow
      ).length || 0;
      const expired = data?.filter((r) => new Date(r.expiry_date) <= now).length || 0;

      setStats({
        total: data?.length || 0,
        valid,
        expiring,
        expired,
      });
    };

    loadStats();
  }, []);

  return (
    <div className="grid grid-cols-4 gap-4">
      <div className="p-4 bg-white rounded shadow">
        <div className="text-2xl font-bold">{stats.total}</div>
        <div className="text-sm text-gray-600">Total Documents</div>
      </div>
      <div className="p-4 bg-green-50 rounded shadow">
        <div className="text-2xl font-bold text-green-600">{stats.valid}</div>
        <div className="text-sm text-gray-600">Valid</div>
      </div>
      <div className="p-4 bg-amber-50 rounded shadow">
        <div className="text-2xl font-bold text-amber-600">{stats.expiring}</div>
        <div className="text-sm text-gray-600">Expiring Soon</div>
      </div>
      <div className="p-4 bg-red-50 rounded shadow">
        <div className="text-2xl font-bold text-red-600">{stats.expired}</div>
        <div className="text-sm text-gray-600">Expired</div>
      </div>
    </div>
  );
};

// 6. CUSTOM VALIDATION RULES
// ===========================

import { validateAIExtraction } from '@/lib/ai-compliance';

// Extend validation with your own rules
const customValidation = (aiAnalysis: any, property: any) => {
  const baseValidation = validateAIExtraction(aiAnalysis);

  // Add custom rule: Check if HMO license max occupants matches property beds
  if (aiAnalysis.documentType === 'HMO License') {
    if (aiAnalysis.maxOccupants < property.beds) {
      baseValidation.issues.push({
        type: 'occupant_mismatch',
        message: `License allows ${aiAnalysis.maxOccupants} occupants but property has ${property.beds} bedrooms`,
        severity: 'warning',
      });
    }
  }

  // Add custom rule: EPC must be C or better for new properties
  if (aiAnalysis.documentType === 'EPC' && property.isNewBuild) {
    if (!['A', 'B', 'C'].includes(aiAnalysis.currentRating)) {
      baseValidation.issues.push({
        type: 'new_build_standard',
        message: 'New builds should have EPC rating of C or better',
        severity: 'warning',
      });
    }
  }

  return baseValidation;
};

// 7. SCHEDULED REMINDERS
// =======================

// Run this daily as a cron job or serverless function
export const sendExpiryReminders = async () => {
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

  // Get all documents expiring in next 30 days
  const { data: expiringDocs } = await supabase
    .from('compliance_records')
    .select('*, properties(*)')
    .lte('expiry_date', thirtyDaysFromNow.toISOString())
    .gte('expiry_date', new Date().toISOString());

  // Send emails
  for (const doc of expiringDocs || []) {
    await sendEmail({
      to: 'david@oxygen.rocks',
      subject: `Compliance Expiring: ${doc.compliance_type} at ${doc.properties.address}`,
      body: `Your ${doc.compliance_type} expires on ${doc.expiry_date}. Please schedule renewal.`,
    });
  }
};

// 8. EXPORT TO PDF REPORT
// ========================

export const generateComplianceReport = async (propertyId: string) => {
  const { data: records } = await supabase
    .from('compliance_records')
    .select('*')
    .eq('property_id', propertyId)
    .order('expiry_date');

  // Generate PDF report (you'd use a library like jsPDF or puppeteer)
  const reportHTML = `
    <h1>Compliance Report</h1>
    <table>
      <thead>
        <tr>
          <th>Document Type</th>
          <th>Issue Date</th>
          <th>Expiry Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        ${records?.map((r) => `
          <tr>
            <td>${r.compliance_type}</td>
            <td>${r.issue_date}</td>
            <td>${r.expiry_date}</td>
            <td>${r.status}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;

  return reportHTML;
};
