// components/ComplianceChecklist.tsx
// Wrapper component for all compliance items

import { ComplianceChecklistItem } from './ComplianceChecklistItem';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

interface Property {
  id: string;
  address: string;
  postcode: string;
}

interface ComplianceChecklistProps {
  property: Property;
  onUpdate?: (data: any) => void;
}

const COMPLIANCE_TYPES = [
  'EPC',
  'EICR',
  'Gas Safety Certificate',
  'Fire Alarm Certificate',
  'Emergency Lighting Certificate',
  'HMO Licence',
  'Legionella Risk Assessment',
];

export const ComplianceChecklist = ({ property, onUpdate }: ComplianceChecklistProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          📋 Compliance Documents
          <span className="text-sm font-normal text-gray-500">
            Upload documents for AI verification
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {COMPLIANCE_TYPES.map((type) => (
            <ComplianceChecklistItem
              key={type}
              complianceType={type}
              propertyId={property.id}
              propertyAddress={property.address}
              propertyPostcode={property.postcode}
              onUpdate={onUpdate}
            />
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800 font-medium mb-2">🤖 AI-Powered Verification</p>
          <ul className="text-xs text-blue-700 space-y-1">
            <li>• Upload any compliance document (PDF, JPG, PNG)</li>
            <li>• AI automatically extracts dates, certificate numbers, and key details</li>
            <li>• Validates expiry dates and property address matching</li>
            <li>• Flags critical issues like expired certificates or defects</li>
            <li>• Auto-checks boxes when documents are valid</li>
          </ul>
        </div>

        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-xs text-amber-700">
            <strong>Note:</strong> AI review is not legal advice. Always instruct a qualified solicitor
            for legal matters and ensure compliance with local regulations.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
