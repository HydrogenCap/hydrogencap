// components/ComplianceChecklistItem.tsx
// AI-powered compliance document upload and verification

import { useState } from 'react';
import { CheckCircle2, AlertCircle, Loader2, Upload, FileText, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { extractTextFromDocument } from '@/lib/pdf-utils';
import { analyzeComplianceDocument, validateAIExtraction } from '@/lib/ai-compliance';
import { useToast } from '@/hooks/use-toast';

interface ComplianceChecklistItemProps {
  complianceType: string;
  propertyId: string;
  propertyAddress: string;
  propertyPostcode: string;
  existingRecord?: {
    id: string;
    issueDate: string;
    expiryDate: string;
    status: string;
    documentUrl: string;
  } | null;
  onUpdate?: (data: any) => void;
}

type UploadStatus = 'idle' | 'processing' | 'success' | 'review' | 'error';

export const ComplianceChecklistItem = ({
  complianceType,
  propertyId,
  propertyAddress,
  propertyPostcode,
  existingRecord,
  onUpdate,
}: ComplianceChecklistItemProps) => {
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setUploadStatus('processing');
    setProgress(0);

    try {
      // Step 1: Extract text from document
      setProgress(20);
      const documentText = await extractTextFromDocument(file);

      if (!documentText || documentText.length < 50) {
        throw new Error('Could not extract enough text from document');
      }

      // Step 2: Analyze with AI
      setProgress(50);
      const analysis = await analyzeComplianceDocument(documentText, complianceType, {
        address: propertyAddress,
        postcode: propertyPostcode,
        id: propertyId,
      });

      setAiAnalysis(analysis);

      // Step 3: Validate results
      setProgress(80);
      const validation = validateAIExtraction(analysis);
      setValidationResult(validation);

      setProgress(100);

      // Determine status
      if (validation.autoApprove) {
        setUploadStatus('success');
        toast({
          title: 'Document verified!',
          description: `${complianceType} has been automatically verified and is valid.`,
        });
      } else if (validation.issues.some((i: any) => i.severity === 'critical')) {
        setUploadStatus('review');
        toast({
          title: 'Issues found',
          description: 'Critical issues detected. Please review before saving.',
          variant: 'destructive',
        });
      } else {
        setUploadStatus('review');
        toast({
          title: 'Review required',
          description: 'Please review the extracted information.',
        });
      }
    } catch (error: any) {
      console.error('Upload failed:', error);
      setUploadStatus('error');
      toast({
        title: 'Upload failed',
        description: error.message || 'Failed to process document',
        variant: 'destructive',
      });
    }
  };

  const handleApprove = () => {
    if (onUpdate && aiAnalysis) {
      onUpdate({
        complianceType,
        propertyId,
        issueDate: aiAnalysis.issueDate || aiAnalysis.dateOfAssessment || aiAnalysis.dateOfInspection,
        expiryDate: aiAnalysis.expiryDate || aiAnalysis.validUntil || aiAnalysis.nextInspectionDue || aiAnalysis.nextServiceDue || aiAnalysis.nextTestDue,
        status: 'valid',
        autoVerified: true,
        aiAnalysis: aiAnalysis,
        file: selectedFile,
      });

      toast({
        title: 'Document saved!',
        description: `${complianceType} has been saved successfully.`,
      });
    }
  };

  const handleReject = () => {
    setUploadStatus('idle');
    setAiAnalysis(null);
    setValidationResult(null);
    setSelectedFile(null);
    setProgress(0);
  };

  // Render based on status
  if (uploadStatus === 'idle' && !existingRecord) {
    return (
      <div className="border-l-4 border-gray-300 pl-4 py-3">
        <label className="flex items-center gap-3 cursor-pointer group">
          <input type="checkbox" disabled className="h-5 w-5 text-blue-600 rounded cursor-not-allowed" />
          <div className="flex-1">
            <span className="text-sm font-medium group-hover:text-blue-600 transition-colors">
              {complianceType} uploaded
            </span>
            <p className="text-xs text-gray-500 mt-1">Status: Missing</p>
          </div>
          <label className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700 cursor-pointer transition-colors flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Upload
            <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileSelect} className="hidden" />
          </label>
        </label>
      </div>
    );
  }

  if (uploadStatus === 'processing') {
    return (
      <div className="border-l-4 border-blue-500 pl-4 py-3 bg-blue-50">
        <div className="flex items-center gap-3">
          <div className="h-5 w-5 flex items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
          </div>
          <div className="flex-1">
            <span className="text-sm font-medium">{complianceType} uploaded</span>
            <div className="mt-2 space-y-2">
              <p className="text-xs text-blue-600 flex items-center gap-2">
                <Loader2 className="h-3 w-3 animate-spin" />
                AI Analyzing document...
              </p>
              <div className="w-full bg-blue-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="text-xs text-gray-600 space-y-1">
                {progress > 10 && (
                  <p className="flex items-center gap-1">
                    <Check className="h-3 w-3 text-green-600" />
                    Document uploaded
                  </p>
                )}
                {progress > 30 && (
                  <p className="flex items-center gap-1">
                    <Check className="h-3 w-3 text-green-600" />
                    Text extracted
                  </p>
                )}
                {progress > 50 && (
                  <p className="flex items-center gap-1">
                    <Check className="h-3 w-3 text-green-600" />
                    AI analysis in progress
                  </p>
                )}
                {progress > 80 && (
                  <p className="flex items-center gap-1">
                    <Check className="h-3 w-3 text-green-600" />
                    Validating results
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (uploadStatus === 'success' && aiAnalysis) {
    const criticalIssues = validationResult?.issues?.filter((i: any) => i.severity === 'critical') || [];
    const warnings = validationResult?.issues?.filter((i: any) => i.severity === 'warning') || [];

    return (
      <div className="border-l-4 border-green-500 pl-4 py-3 bg-green-50">
        <label className="flex items-start gap-3">
          <div className="h-5 w-5 flex items-center justify-center mt-1">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">{complianceType} uploaded</span>
              <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                <Check className="h-3 w-3" />
                Auto-verified
              </span>
            </div>

            <Card className="mt-2 p-3 bg-white border-green-200">
              <p className="text-xs font-semibold text-gray-700 mb-2 flex items-center gap-1">
                🤖 AI Analysis Results
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-gray-500">Issue Date:</span>
                  <span className="ml-2 font-medium">
                    {aiAnalysis.issueDate || aiAnalysis.dateOfAssessment || aiAnalysis.dateOfInspection || 'N/A'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500">Expiry Date:</span>
                  <span className="ml-2 font-medium">
                    {aiAnalysis.expiryDate || aiAnalysis.validUntil || aiAnalysis.nextInspectionDue || 'N/A'}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-gray-500">Status:</span>
                  <span className="ml-2 font-medium text-green-600">
                    Valid (expires in {aiAnalysis.daysUntilExpiry} days)
                  </span>
                </div>
                {aiAnalysis.certificateNumber && (
                  <div className="col-span-2">
                    <span className="text-gray-500">Certificate #:</span>
                    <span className="ml-2 font-medium">{aiAnalysis.certificateNumber}</span>
                  </div>
                )}
              </div>

              {warnings.length > 0 && (
                <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded">
                  <p className="text-xs font-semibold text-amber-700 mb-1">⚠️ Warnings:</p>
                  <ul className="text-xs text-amber-600 space-y-1">
                    {warnings.map((issue: any, idx: number) => (
                      <li key={idx}>• {issue.message}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="mt-3 flex gap-2">
                <Button size="sm" onClick={handleApprove} className="bg-green-600 hover:bg-green-700">
                  <Check className="h-3 w-3 mr-1" />
                  Approve & Save
                </Button>
                <Button size="sm" variant="outline" onClick={handleReject}>
                  <X className="h-3 w-3 mr-1" />
                  Reject
                </Button>
              </div>
            </Card>
          </div>
        </label>
      </div>
    );
  }

  if (uploadStatus === 'review' && aiAnalysis) {
    const criticalIssues = validationResult?.issues?.filter((i: any) => i.severity === 'critical') || [];
    const warnings = validationResult?.issues?.filter((i: any) => i.severity === 'warning') || [];

    return (
      <div className="border-l-4 border-amber-500 pl-4 py-3 bg-amber-50">
        <label className="flex items-start gap-3">
          <div className="h-5 w-5 flex items-center justify-center mt-1">
            <AlertCircle className="h-5 w-5 text-amber-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">{complianceType} uploaded</span>
              <span className="text-xs text-amber-600 font-medium flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                Review Required
              </span>
            </div>

            <Card className="mt-2 p-3 bg-white border-amber-200">
              <p className="text-xs font-semibold text-gray-700 mb-2">🤖 AI Analysis Results</p>

              {criticalIssues.length > 0 && (
                <div className="mb-3 p-2 bg-red-50 border border-red-200 rounded">
                  <p className="text-xs font-semibold text-red-700 mb-1 flex items-center gap-1">
                    <X className="h-3 w-3" />
                    Critical Issues:
                  </p>
                  <ul className="text-xs text-red-600 space-y-1">
                    {criticalIssues.map((issue: any, idx: number) => (
                      <li key={idx}>• {issue.message}</li>
                    ))}
                  </ul>
                </div>
              )}

              {warnings.length > 0 && (
                <div className="mb-3 p-2 bg-amber-50 border border-amber-200 rounded">
                  <p className="text-xs font-semibold text-amber-700 mb-1">⚠️ Warnings:</p>
                  <ul className="text-xs text-amber-600 space-y-1">
                    {warnings.map((issue: any, idx: number) => (
                      <li key={idx}>• {issue.message}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                <div>
                  <span className="text-gray-500">Issue Date:</span>
                  <span className="ml-2 font-medium">
                    {aiAnalysis.issueDate || aiAnalysis.dateOfAssessment || aiAnalysis.dateOfInspection || 'N/A'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500">Expiry Date:</span>
                  <span className="ml-2 font-medium">
                    {aiAnalysis.expiryDate || aiAnalysis.validUntil || aiAnalysis.nextInspectionDue || 'N/A'}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                {criticalIssues.length === 0 && (
                  <Button size="sm" onClick={handleApprove} variant="default">
                    <Check className="h-3 w-3 mr-1" />
                    Accept Anyway
                  </Button>
                )}
                <Button size="sm" variant="destructive" onClick={handleReject}>
                  <X className="h-3 w-3 mr-1" />
                  Delete & Re-upload
                </Button>
              </div>
            </Card>
          </div>
        </label>
      </div>
    );
  }

  if (uploadStatus === 'error') {
    return (
      <div className="border-l-4 border-red-500 pl-4 py-3 bg-red-50">
        <div className="flex items-center gap-3">
          <X className="h-5 w-5 text-red-600" />
          <div className="flex-1">
            <span className="text-sm font-medium text-red-700">{complianceType} upload failed</span>
            <p className="text-xs text-red-600 mt-1">Please try again or upload a different file</p>
          </div>
          <Button size="sm" variant="outline" onClick={handleReject}>
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  // Existing record state
  if (existingRecord) {
    return (
      <div className="border-l-4 border-green-500 pl-4 py-3 bg-green-50">
        <label className="flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-green-600" />
          <div className="flex-1">
            <span className="text-sm font-medium">{complianceType} uploaded</span>
            <p className="text-xs text-gray-600 mt-1">
              Valid until {existingRecord.expiryDate}
            </p>
          </div>
          <Button size="sm" variant="outline">
            <FileText className="h-3 w-3 mr-1" />
            View
          </Button>
        </label>
      </div>
    );
  }

  return null;
};
