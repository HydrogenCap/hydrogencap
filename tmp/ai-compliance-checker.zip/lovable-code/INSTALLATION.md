# AI Compliance Checker - Installation Guide for Lovable

## 📦 Required Dependencies

Add these to your `package.json`:

```json
{
  "dependencies": {
    "pdfjs-dist": "^3.11.174",
    "@anthropic-ai/sdk": "^0.20.0"
  }
}
```

Or install via npm:
```bash
npm install pdfjs-dist @anthropic-ai/sdk
```

## 🔑 Environment Variables

Add to your `.env` file:

```env
VITE_ANTHROPIC_API_KEY=your-api-key-here
```

To get your API key:
1. Go to https://console.anthropic.com
2. Sign up or log in
3. Navigate to API Keys
4. Create a new key
5. Copy and paste into `.env` file

## 📁 File Structure

Copy these files into your Lovable project:

```
src/
├── lib/
│   ├── ai-compliance.ts       # AI analysis logic
│   └── pdf-utils.ts           # PDF text extraction
├── components/
│   ├── ComplianceChecklistItem.tsx  # Individual checklist item
│   └── ComplianceChecklist.tsx      # Full checklist wrapper
└── .env                        # Your environment variables
```

## 🚀 How to Use

### Option 1: Add to Property Detail Page

```tsx
// In your property detail page (e.g., PropertyDetail.tsx)

import { ComplianceChecklist } from '@/components/ComplianceChecklist';

export const PropertyDetail = ({ propertyId }: { propertyId: string }) => {
  const property = {
    id: propertyId,
    address: '47 Pinewood Drive, Cheltenham',
    postcode: 'GL51 9QH'
  };

  const handleComplianceUpdate = async (data: any) => {
    console.log('Compliance data to save:', data);
    
    // Save to your database (Supabase, Firebase, etc.)
    // Example with Supabase:
    // const { error } = await supabase
    //   .from('compliance_records')
    //   .insert({
    //     property_id: data.propertyId,
    //     compliance_type: data.complianceType,
    //     issue_date: data.issueDate,
    //     expiry_date: data.expiryDate,
    //     status: data.status,
    //     auto_verified: data.autoVerified,
    //     ai_analysis: data.aiAnalysis
    //   });
  };

  return (
    <div className="space-y-6">
      {/* Your existing property detail sections */}
      
      <ComplianceChecklist 
        property={property} 
        onUpdate={handleComplianceUpdate}
      />
    </div>
  );
};
```

### Option 2: Standalone Compliance Page

```tsx
// Create a new page: CompliancePage.tsx

import { ComplianceChecklist } from '@/components/ComplianceChecklist';
import { useParams } from 'react-router-dom';

export const CompliancePage = () => {
  const { propertyId } = useParams();
  
  // Fetch property data
  const property = {
    id: propertyId,
    address: '47 Pinewood Drive, Cheltenham',
    postcode: 'GL51 9QH'
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Property Compliance</h1>
      <ComplianceChecklist property={property} />
    </div>
  );
};
```

## 🗄️ Database Schema

You'll need a table to store compliance records. Example for Supabase:

```sql
-- Create compliance_records table
create table compliance_records (
  id uuid default uuid_generate_v4() primary key,
  property_id text not null,
  compliance_type text not null,
  issue_date date,
  expiry_date date,
  status text, -- 'valid', 'expired', 'expiring_soon'
  auto_verified boolean default false,
  ai_analysis jsonb, -- Store full AI analysis
  document_url text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create index for faster queries
create index idx_compliance_property on compliance_records(property_id);
create index idx_compliance_expiry on compliance_records(expiry_date);
```

## 🎨 Customization

### Change Compliance Types

Edit `ComplianceChecklist.tsx`:

```tsx
const COMPLIANCE_TYPES = [
  'EPC',
  'EICR',
  'Gas Safety Certificate',
  'Fire Alarm Certificate',
  'Emergency Lighting Certificate',
  'HMO Licence',
  'Legionella Risk Assessment',
  // Add your own types here
  'Building Insurance',
  'Contents Insurance',
];
```

### Modify AI Prompts

Edit `lib/ai-compliance.ts` to customize how AI analyzes documents. Each compliance type has its own prompt template.

### Change Styling

All components use Tailwind classes and shadcn/ui components, so you can easily customize:

- Colors: Change `bg-green-500` to `bg-blue-500`, etc.
- Sizing: Modify `text-sm`, `p-4`, `gap-3`, etc.
- Borders: Adjust `border-l-4`, `rounded-lg`, etc.

## 🧪 Testing

### Test with Sample Documents

1. **Gas Safety Certificate**: Upload a PDF gas safety certificate
2. **EPC**: Upload an Energy Performance Certificate
3. **EICR**: Upload an Electrical Installation Condition Report

### What to Check

✅ File uploads successfully
✅ Progress bar shows during processing
✅ AI extracts dates correctly
✅ Address matching works
✅ Expired documents are flagged
✅ Valid documents auto-approve
✅ Issues are displayed clearly

### Common Issues

**"Failed to extract text from PDF"**
- Make sure PDF contains actual text (not scanned image)
- Try a different PDF

**"API request failed"**
- Check your API key is set correctly in `.env`
- Ensure you have API credits in your Anthropic account
- Check network/CORS settings

**"Low confidence" warning**
- Document might be poorly scanned
- Try uploading a clearer version
- Or manually review and approve

## 💰 Cost Estimates

**Claude API Pricing:**
- ~2,000 tokens per document = ~$0.006 per document
- 7 documents per property = ~$0.04 per property
- 29 properties = ~$1.20 total
- Monthly cost (if re-checking): ~$5/month

**This is extremely cheap compared to:**
- Manual data entry time: £50+ in labor
- Missed compliance deadline: £5,000+ fine
- Legal review: £200+ per property

## 🚨 Important Notes

### Legal Disclaimer
- AI verification is a tool to assist, not replace professional advice
- Always have solicitors review critical documents
- AI may make mistakes - always double-check important details
- You are responsible for ensuring compliance

### Data Privacy
- Documents are sent to Anthropic's API for processing
- Text is extracted but not stored by Anthropic
- Consider your privacy requirements
- For highly sensitive documents, use manual review

### Limitations
- Works best with clear, text-based PDFs
- Scanned/image PDFs need OCR (not yet implemented)
- AI confidence varies by document quality
- Cannot replace professional judgment

## 📞 Support

### If Something Doesn't Work

1. **Check the browser console** (F12) for errors
2. **Verify API key** is set correctly
3. **Test with a simple PDF** first
4. **Check file size** (keep under 5MB for best results)

### Need Help?

- Check Lovable documentation: https://lovable.dev/docs
- Claude API docs: https://docs.anthropic.com
- PDF.js docs: https://mozilla.github.io/pdf.js/

## ✅ Checklist

Before going live:

- [ ] Install all dependencies
- [ ] Set up API key in `.env`
- [ ] Copy all files to your project
- [ ] Create database table for compliance records
- [ ] Test with 3-5 sample documents
- [ ] Verify auto-save works
- [ ] Test on mobile devices
- [ ] Add error handling for your use case
- [ ] Set up backup/manual entry option
- [ ] Document for your team

## 🎯 Next Steps

Once this is working:

1. **Add file storage**: Upload PDFs to cloud storage (S3, Cloudinary)
2. **Build history view**: Show all past compliance records
3. **Add reminders**: Email alerts 30 days before expiry
4. **Generate reports**: Export compliance status to PDF
5. **Bulk upload**: Process multiple documents at once
6. **OCR support**: Handle scanned documents (add Tesseract.js)
7. **Mobile app**: Make it work in your phone's camera

---

**You're all set! 🎉**

Start by uploading a test document and watching the AI work its magic. The time savings will be immediate.
